Dear participant, please find included two versions of the calibration program aimed to determine the performance factor of your machine. 
 
May you be using a Windows 64-bit operating system then please run the Benchmark_64.exe program, regardless of your own code being 32 or 64 bit. May you be using a 32-bit machine then please run the Benchmark_32.exe program.
 
You should use the value returned to determine the time limit in your case: see the challenge setup document for details.
